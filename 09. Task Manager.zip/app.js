function solve() {
    document.querySelector('form').addEventListener('submit', onSubmit);
    
    const titleRef = document.getElementById('task')
    const descRef = document.getElementById('description');
    const dateRef = document.getElementById('date');

    const [formSection, openSection, inProgressSection, completeSection] = document.querySelectorAll('section');

    const openRef = openSection.children[1];       // <div> със задачи в "Open"
    const inProgressRef = inProgressSection.children[1]; // <div> със задачи в "In Progress"
    const completeRef = completeSection.children[1]; 

    function onSubmit(event){
        event.preventDefault()
        const title = titleRef.value;
        const description = descRef.value;
        const date = dateRef.value;

        titleRef.value = '';
        descRef.value = '';
        dateRef.value = ''

        if(!title || !description || !date){
            return;
        }
        const article = createArticle(title, description, date)
        openRef.appendChild(article)
    }
    function createArticle(title, description, date){
        const article = document.createElement('article');
        const h3 = document.createElement('h3');
        h3.textContent = title;

        const pDesc = document.createElement('p');
        pDesc.textContent = 'Description: ' + description;

        const pDate = document.createElement('p');
        pDate.textContent = 'Due Date: ' + date;

        const container = document.createElement('div')
        container.classList.add('flex');

        const startBtn = createBtn("green", "Start", onStart);
        const deleteBtn = createBtn("red", "Delete", onDelete);

        container.appendChild(startBtn);
        container.appendChild(deleteBtn);

        article.appendChild(h3);
        article.appendChild(pDesc);
        article.appendChild(pDate);
        article.appendChild(container)

        return article;
    }
    function createBtn(className, text, handler){
        const btn = document.createElement('button');
        btn.classList.add(className);
        btn.textContent = text;
        btn.addEventListener('click', handler);
        return btn;
    }
    function onStart(event){
        const container = event.target.parentElement;
        const article = container.parentElement;

        container.innerHTML = '';
        container.appendChild(createBtn('red', 'Delete', onDelete));
        container.appendChild(createBtn('orange', 'Finish', onComplete));

        inProgressRef.appendChild(article)
    }
    function onDelete(event){
       const article = event.target.parentElement.parentElement
        article.remove()


    }
    function onComplete(event){
        const container = event.target.parentElement;
        const article = container.parentElement;
        container.remove();
        completeRef.appendChild(article)

    }
}