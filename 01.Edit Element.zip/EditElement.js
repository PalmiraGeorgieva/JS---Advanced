function editElement(ref, match, replacer) {
    // TOD
    let text = ref.textContent
    ref.textContent = text.replaceAll(match, replacer)
    
}