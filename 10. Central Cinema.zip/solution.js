function solve() {
    const [nameInput, hallInput, priceInput] = document.querySelectorAll('#add-new input');
    const onScreen = document.querySelector('#add-new button');
    const moviesUl = document.querySelector('#movies ul');
    const archiveUl = document.querySelector('#archive ul');
    const clearBtn = document.querySelector('#archive button');

    onScreen.addEventListener('click', (e) => {
        e.preventDefault();

        const name = nameInput.value.trim();
        const hall = hallInput.value.trim();
        const price = Number(priceInput.value.trim());

        if (!name || !hall || isNaN(price) || price <= 0) return;

        const li = document.createElement('li');

        const spanName = document.createElement('span');
        spanName.textContent = name;

        const strongHall = document.createElement('strong');
        strongHall.textContent = `Hall: ${hall}`;

        const div = document.createElement('div');

        const strongPrice = document.createElement('strong');
        strongPrice.textContent = price.toFixed(2);

        const ticketsInput = document.createElement('input');
        ticketsInput.placeholder = 'Tickets Sold';

        const archiveBtn = document.createElement('button');
        archiveBtn.textContent = 'Archive';

        div.appendChild(strongPrice);
        div.appendChild(ticketsInput);
        div.appendChild(archiveBtn);

        li.appendChild(spanName);
        li.appendChild(strongHall);
        li.appendChild(div);

        moviesUl.appendChild(li);

        nameInput.value = '';
        hallInput.value = '';
        priceInput.value = '';

        archiveBtn.addEventListener('click', () => {
            const ticketsValue = ticketsInput.value.trim();
            if (ticketsValue === '') return; 
            const tickets = Number(ticketsValue);

            if (isNaN(tickets) || tickets < 0) return;

            const total = tickets * price;

            const archiveLi = document.createElement('li');
            const archiveSpan = document.createElement('span');
            archiveSpan.textContent = name;

            const archiveStrong = document.createElement('strong');
            archiveStrong.textContent = `Total amount: ${total.toFixed(2)}`;

            const deleteBtn = document.createElement('button');
            deleteBtn.textContent = 'Delete';

            deleteBtn.addEventListener('click', () => archiveLi.remove());

            archiveLi.appendChild(archiveSpan);
            archiveLi.appendChild(archiveStrong);
            archiveLi.appendChild(deleteBtn);

            archiveUl.appendChild(archiveLi);
            li.remove();
        });
    });

    clearBtn.addEventListener('click', () => {
        Array.from(archiveUl.children).forEach(li => li.remove());
    });
}