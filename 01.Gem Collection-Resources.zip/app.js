window.addEventListener("load", solve);

function solve() {
   const gemNameRef = document.getElementById('gem-name');
   const colorRef = document.getElementById('color');
   const caratsRef = document.getElementById('carats');
   const priceRef = document.getElementById('price');
   const addBtn = document.getElementById('add-btn');
   const typeRef = document.getElementById('type');
   const previewList = document.getElementById('preview-list');
   const collectionList = document.getElementById('collection');

   addBtn.addEventListener('click', (e) => {
      const gemName = gemNameRef.value.trim();
      const color = colorRef.value.trim();
      const carats = caratsRef.value.trim();
      const price = priceRef.value.trim();
      const type = typeRef.value.trim();

      if(!gemName || !color || !carats || !price || !type){
        return
      }

      const li = document.createElement('li');
      
      const article = document.createElement('article');
      const h4 = document.createElement('h4');
      h4.textContent = `${gemName}`;

      const pColor = document.createElement('p');
      pColor.textContent = `Color: ${color}`;

      const pCarat = document.createElement('p');
      pCarat.textContent = `Carats: ${carats}`

      const pPrice = document.createElement('p');
      pPrice.textContent = `Price: ${price}$`

      const pType = document.createElement('p')
      pType.textContent = `Type: ${type}`;

      article.appendChild(h4);
      article.appendChild(pColor);
      article.appendChild(pCarat);
      article.appendChild(pPrice);
      article.appendChild(pType);
      li.appendChild(article);

      const saveBtn = document.createElement('button');
      saveBtn.textContent = 'Save to Collection';
      saveBtn.classList.add('save-btn');

      const editBtn = document.createElement('button');
      editBtn.textContent = 'Edit Information';
      editBtn.classList.add('edit-btn');

      const cancelBtn = document.createElement('button');
      cancelBtn.textContent = 'Cancel'
      cancelBtn.classList.add('cancel-btn');

      li.appendChild(saveBtn)
      li.appendChild(editBtn)
      li.appendChild(cancelBtn);
      previewList.appendChild(li)

      gemNameRef.value = '';
      colorRef.value = '';
      caratsRef.value = '';
      priceRef.value = '';
      typeRef.value = '';

      addBtn.disabled = true;

      editBtn.addEventListener('click', () => {
        gemNameRef.value = gemName;
        colorRef.value = color;
        caratsRef.value = carats;
        priceRef.value = price;
        typeRef.value = type;

        li.remove(); // Премахва preview елемента
        addBtn.disabled = false;

      });

      saveBtn.addEventListener('click', () => {
        const collectionItem = document.createElement('li');
        const text = document.createElement('p');
        text.classList.add('collection-item');
        text.textContent = `${gemName} - Color: ${color}/ Carats: ${carats}/ Price: ${price}$/ Type: ${type}`

        collectionItem.appendChild(text);
        collectionList.appendChild(collectionItem);

        li.remove();
        addBtn.disabled = false;
      });

      cancelBtn.addEventListener('click', () => {
        li.remove();
        addBtn.disabled = false;
      });

   });

}
