function attachEventsListeners() {
    const inputField = document.getElementById('inputDistance');
    const outputField = document.getElementById('outputDistance');
    const inputUnits = document.getElementById('inputUnits');
    const outputUnits = document.getElementById('outputUnits');
    const convertBtn = document.getElementById('convert');

    const convertToMeters = {
        km: 1000,
        m: 1,
        cm: 0.01,
        mm: 0.001,
        mi: 1609.34,
        yrd: 0.9144,
        ft: 0.3048,
        in: 0.0254
    };
    
    convertBtn.addEventListener('click', () => {
        let inputValue = Number(inputField.value)

        let valueMeters = inputValue *  convertToMeters[inputUnits.value];

        let convertedValue = valueMeters / convertToMeters[outputUnits.value]
        outputField.value = convertedValue
    })
}