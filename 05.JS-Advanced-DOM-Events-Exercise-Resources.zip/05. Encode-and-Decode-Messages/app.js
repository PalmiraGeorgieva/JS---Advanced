function encodeAndDecodeMessages() {
    const divs = document.querySelectorAll('main div');

    const senderTextarea = divs[0].querySelector('textarea');
    const senderBtn = divs[0].querySelector('button');

    const receiverTextarea = divs[1].querySelector('textarea');
    const receiverBtn = divs[1].querySelector('button');

    senderBtn.addEventListener('click', () => {
        const message = senderTextarea.value;
        let encodedMsg = '';

        for(let i = 0; i < message.length; i++){
            encodedMsg += String.fromCharCode(message.charCodeAt(i) + 1);

        }
        senderTextarea.value = '';
        receiverTextarea.value = encodedMsg
    });

    receiverBtn.addEventListener('click', () => {
        const encodedMsg = receiverTextarea.value
        let decodedMsg = '';

        for(let i = 0; i < encodedMsg.length; i++){
            decodedMsg += String.fromCharCode(encodedMsg.charCodeAt(i) - 1);
        }

        receiverTextarea.value = decodedMsg;
    })

}