function attachEventsListeners() {
   const btnRef = document.querySelectorAll("input[type='button']");
   Array.from(btnRef).forEach(btn => btn.addEventListener('click', onClick))

   function onClick(e) {
    const targetRef = e.currentTarget;
    const parentRef = targetRef.parentElement;
    const childrenRef = parentRef.children;
    const inputRef = childrenRef[1];

    const currentValue = Number(inputRef.value);
    const unit = inputRef.id;

    switch(unit){
        case 'days': propagateNewValue(currentValue); break;
        case 'hours': propagateNewValue(currentValue / 24); break;
        case 'minutes': propagateNewValue(currentValue / 24 / 60); break;
        case 'seconds': propagateNewValue(currentValue / 24 / 60 / 60); break;           
    }
   }
   function propagateNewValue(days){
    const inputRef = document.querySelectorAll("input[type='text']")

    inputRef[0].value = days;
    inputRef[1].value = Math.round(days * 24);
    inputRef[2].value = Math.round(days * 24 * 60);
    inputRef[3].value = Math.round(days * 24 * 60 * 60);

   }
}