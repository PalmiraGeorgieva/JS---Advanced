function attachGradientEvents() {
     const gradientRef = document.getElementById('gradient');
    const output = document.getElementById('result');

    gradientRef.addEventListener('mousemove', onMouseMove);
    gradientRef.addEventListener('mouseout', onMouseOut);

    function onMouseMove(e) {
        let eventOffset = e.offsetX;
        let offsetWidth = e.target.clientWidth;
        let percent = Math.trunc((eventOffset / offsetWidth) * 100);
        output.textContent = percent + '%';
    }

    function onMouseOut() {
        output.textContent = '';
    }
}