function solve() {
   document.querySelector('#searchBtn').addEventListener('click', onClick);
   const searchRef = document.getElementById('searchField');
   const tabelRowRef = document.querySelectorAll('tbody tr')

   function onClick() {
      const searchText = searchRef.value;
      if(!searchText) {
         return;
      }

      searchRef.value = '';

      for(let i = 0; i < tabelRowRef.length; i++){
         const tableDataRef = tabelRowRef[i].querySelectorAll('td');
         for(let col = 0; col < tableDataRef.length; col++){
            const tableData = tableDataRef[col].textContent;
            if(tableData.includes(searchText)){
               tabelRowRef[i].classList.add('select');
               break;
            }else {
               tabelRowRef[i].classList.remove('select')
            }
         }
      }

   }
}