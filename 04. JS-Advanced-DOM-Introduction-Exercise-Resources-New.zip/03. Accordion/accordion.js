function toggle() {
    const btn = document.getElementsByClassName('button')[0];
    let extra = document.getElementById('extra');

    if(extra.style.display === 'none' || extra.style.display === ''){
        extra.style.display = 'block'
        btn.textContent = '[Less]'
    } else if(extra.style.display === 'block' ) {
        extra.style.display = 'none'
        btn.textContent = '[More]'
    }
}