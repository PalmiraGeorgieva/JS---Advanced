function subtract() {
    const firstNumRef = document.getElementById('firstNumber');
    const secondNumRef = document.getElementById('secondNumber');
    const result = document.getElementById('result')

    result.textContent = Number(firstNumRef.value) - Number(secondNumRef.value)

}