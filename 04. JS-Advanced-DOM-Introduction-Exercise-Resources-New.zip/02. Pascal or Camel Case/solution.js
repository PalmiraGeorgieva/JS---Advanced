function solve() {
  let textInput = document.getElementById('text').value;
  let nameCase = document.getElementById('naming-convention').value;
  let resultRef = document.getElementById('result');

  let word = textInput.toLowerCase().split(' ');
  let result = ''
  if(nameCase === 'Camel Case'){
    let result = word[0];
    for(let i = 1; i < word.length; i++) {
      result += word[i][0].toUpperCase() + word[i].slice(1)
    }
    resultRef.textContent = result
  }else if(nameCase === 'Pascal Case'){

    for(let el of word){
      result += el[0].toUpperCase() + el.slice(1);
      
    }
    resultRef.textContent = result
  } else {
    resultRef.textContent = 'Error!'
  }
}