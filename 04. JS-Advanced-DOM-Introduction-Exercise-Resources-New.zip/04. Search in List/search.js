function search() {
   const townsList = document.querySelectorAll('#towns li')
   const searchText = document.getElementById('searchText');
   const resultRef = document.getElementById('result');

   let text = searchText.value.toLowerCase();
   let matches = 0;

   for(let i = 0; i < townsList.length; i++){
      let li = townsList[i]

      li.style.fontWeight = 'normal';
      li.style.textDecoration = 'none';

      if(li.textContent.toLowerCase().includes(text) && text !== ''){
         li.style.fontWeight = 'bold';
         li.style.textDecoration = 'underline';
         matches++;
      }
   }
   resultRef.textContent = `${matches} matches found`



}
