function generateReport() {
    const checkboxes = document.querySelectorAll('thead input[type="checkbox"]');
    const rows = document.querySelectorAll('tbody tr');
    let output = [];

    rows.forEach(row => {
        let cols = row.querySelectorAll('td');
        let currObj = {};
        checkboxes.forEach((cb, index) => {
            if(cb.checked){
                let key = cb.name;
                let value = cols[index].textContent;
                currObj[key] = value;
            }
        });
        output.push(currObj)
    });
    document.getElementById("output").value = JSON.stringify(output, null, 2)
}