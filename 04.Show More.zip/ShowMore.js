function showText() {
    // TODO
    const btn = document.getElementById('more');
    const text = document.getElementById('text');

    text.style.display = 'inline'
    btn.style.display = 'none'
}